import img1 from './Images/pr1.png'
import img2 from './Images/pr02.png'
import img3 from './Images/pr3.png'
import img4 from './Images/pr4.png'
import img5 from './Images/pr5.png'
// import img6 from './Images/pr1'
// import img7 from './image/pr_06.png'
// import img8 from './image/pr_01.png'
const  productDetail=[
    { id: "101", name: "Bouncer", image: img1, price: 150, quantity: 0 ,rating: "⭐⭐⭐⭐⭐" },
    { id: "102", name: "Doll", image: img2, price: 250, quantity: 0,rating: "⭐⭐" },
    { id: "103", name: "Toy Wagon", image: img1, price: 550, quantity: 0,rating: "⭐⭐⭐⭐" },
    { id: "104", name: "Basketball", image: img2, price: 300, quantity: 0 ,rating: "⭐"},
    { id: "105", name: "cricket set", image: img1, price: 250, quantity: 0,rating: "⭐⭐⭐" },
    { id: "106", name: "kids mini pack", image: img2, price: 158, quantity: 0,rating: "⭐⭐⭐⭐"},
    { id: "107", name: "baby ball", image: img1, price: 850, quantity: 0,rating: "⭐⭐" },
    { id: "108", name: "Bouncer", image: img2, price: 450, quantity: 0,rating: "⭐⭐⭐⭐⭐" },
    { id: "108", name: "Bouncer", image: img1, price: 450, quantity: 0,rating: "⭐⭐⭐⭐⭐" }
]

export default productDetail